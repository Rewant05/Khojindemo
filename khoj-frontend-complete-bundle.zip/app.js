document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const mobilePanel = document.querySelector(".mobile-panel");

  if (menuToggle && mobilePanel) {
    menuToggle.addEventListener("click", () => {
      mobilePanel.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", mobilePanel.classList.contains("open") ? "true" : "false");
    });
  }

  const yearLine = document.getElementById("year-line");
  if (yearLine) {
    yearLine.textContent = `© ${new Date().getFullYear()} KHOJ — Built for trusted recovery.`;
  }

  const revealItems = document.querySelectorAll(".reveal");
  if (revealItems.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    revealItems.forEach((item) => io.observe(item));
  }

  document.querySelectorAll(".file-input").forEach((input) => {
    input.addEventListener("change", () => {
      const target = document.getElementById(input.dataset.preview);
      if (!target) return;
      target.textContent = input.files.length ? input.files[0].name : "No file selected yet.";
    });
  });
});
